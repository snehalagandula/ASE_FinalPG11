--<ScriptOptions statementTerminator=";"/>

CREATE TABLE adminlogin (
	username VARCHAR(30),
	password VARCHAR(30)
) ENGINE=InnoDB;

